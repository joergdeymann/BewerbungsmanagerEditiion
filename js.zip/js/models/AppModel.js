import { CompanyModel } from './CompanyModel.js';
import { ContactModel } from './ContactModel.js';
import { BenefitsModel } from './BenefitsModel.js';
import { ApplicationModel } from './ApplicationModel.js';
import { ReferenceModel } from './ReferenceModel.js';
import { JobModel } from './JobModel.js';
import { QualificationModel } from './QualificationModel.js';
import { ImportedTextModel } from './ImportedTextModel.js';

export class AppModel {
    constructor() {
        this.id = 0;
        this.createDate = new Date().toISOString();
        this.status = "";
        this.updatedAt = "";
        this.job = new JobModel();
        this.company = new CompanyModel();

        // Jetzt als leere Listen (Arrays) initialisiert
        this.contacts = [];
        this.qualifications = new QualificationModel();
        this.benefits = new BenefitsModel();
        this.application = new ApplicationModel();
        this.references = [];

        this.actionHistory = [];
        this.importedRawData = [];
    }

    get data() {
        return {
            id: this.id,
            createDate: this.createDate,
            status: this.status,
            updatedAt: this.updatedAt,
            job: this.job.data,
            company: this.company.data,
            contacts: this.contacts.map(contact => contact.data),
            qualifications: this.qualifications.data,
            benefits: this.benefits.data,
            application: this.application.data,
            references: this.references.map(reference => reference.data),
            actionHistory: this.actionHistory,
            importedRawData: this.importedRawData.map(entry => entry.data)
        };
    }

    set data(raw) {
        if (!raw) return;

        this.id = raw.id ?? this.id;
        this.createDate = raw.createDate ?? this.createDate;
        this.status = raw.status ?? this.status;
        this.updatedAt = raw.updatedAt ?? this.updatedAt;
        this.actionHistory = raw.actionHistory ?? this.actionHistory;

        if (raw.job) {
            this.job.data = raw.job;
        }

        if (raw.company) {
            this.company.data = raw.company;
        }

        if (raw.qualifications) {
            this.qualifications.data = raw.qualifications;
        }

        if (raw.benefits) {
            this.benefits.data = raw.benefits;
        }

        if (raw.application) {
            this.application.data = raw.application;
        }

        // DIE ARRAYS IM SETTER ANPASSEN:
        if (raw.contacts && Array.isArray(raw.contacts)) {
            // Wir leeren das aktuelle Array, um Duplikate beim erneuten Laden zu verhindern
            this.contacts = [];

            // Jeden rohen Kontakteintrag in ein echtes Modell umwandeln
            for (const rawContact of raw.contacts) {
                const contactInstance = new ContactModel();
                contactInstance.data = rawContact; // Nutzt den Setter von ContactModel
                this.contacts.push(contactInstance); // Ab in die Liste!
            };
        }

        if (raw.references && Array.isArray(raw.references)) {
            this.references = [];

            for (const rawReference of raw.references) {
                const referenceInstance = new ReferenceModel();
                referenceInstance.data = rawReference;
                this.references.push(referenceInstance);
            }
        }

        if (raw.importedRawData && Array.isArray(raw.importedRawData)) {
            this.importedRawData = raw.importedRawData.map(rawEntry => {
                const entry = new ImportedTextModel();
                // Abwärtskompatibel: alte Testdaten waren reine Strings.
                entry.data = typeof rawEntry === "string"
                    ? { content: rawEntry }
                    : rawEntry;
                return entry;
            });
        }
    }

	static fromData(raw) {
        const model = new AppModel();
        model.id = raw.id;
        model.company = raw.company;
        model.createDate = raw.createDate;
        // ... hier alle Felder zuweisen
        return model;
    }
	
	// HILFSMETHODE: Erstellt und pusht einen neuen Kontakt direkt als Modell
	addContact(contactOrName, email = "", phone = "") {
        if (contactOrName instanceof ContactModel) {
            this.contacts.push(contactOrName);
            return contactOrName;
        }

        const newContact = new ContactModel();
        newContact.name.data =
            typeof contactOrName === "string"
                ? { lastname: contactOrName }
                : contactOrName;
        newContact.email = email;
        newContact.phone = phone;
        
        this.contacts.push(newContact);
        return newContact;
    }

    addContact(contact) {	
		this.contacts.push(contact)
	
	}	
}