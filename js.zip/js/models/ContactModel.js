import { NameModel } from "./NameModel.js";

export class ContactModel {
    constructor() {
        this.id = crypto.randomUUID();
        this.role = "";
        this.name = new NameModel();
        this.img = "";
        this.email = "";
        this.phone = "";
    }

    get data() {
        return {
            id: this.id,
            role: this.role,
            name: this.name.data,
            img: this.img,
            email: this.email,
            phone: this.phone
        };
    }

    set data(raw) {
        if (!raw) return;
        this.id = raw.id || this.id;
        this.role = raw.role ?? this.role;
        this.name.data = raw.name;
        this.img = raw.img ?? this.img;
        this.email = raw.email ?? this.email;
        this.phone = raw.phone ?? this.phone;
    }
}
