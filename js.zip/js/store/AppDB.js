import { LocalDB } from "./LocalDB.js";
import { AppModel } from "../models/AppModel.js";

export class AppDB {
    static storeName = "Bewerbungsmanager";

    constructor() {
        this.ready = LocalDB.create(AppDB.storeName);
    }

    // Wählt den Object Store erneut aus, falls LocalDB zwischenzeitlich für einen
    // anderen Store verwendet wurde. So bleibt der Store für jede Operation zuverlässig verfügbar.
    async ensureStore() {
        await this.ready;
        if (LocalDB.storeName !== AppDB.storeName) {
            await LocalDB.create(AppDB.storeName);
        }
    }

    async save(appModel) {
        await this.ensureStore();
        return LocalDB.updateOrAdd(appModel.data);
    }

    async get(id) {
        await this.ensureStore();
        const raw = await LocalDB.get(id);
        if (!raw) return null;

        const app = new AppModel();
        app.data = raw;
        return app;
    }

    async getAll() {
        await this.ensureStore();
        const rawList = await LocalDB.get();
        return rawList.map(raw => {
            const app = new AppModel();
            app.data = raw;
            return app;
        });
    }

    async delete(id) {
        await this.ensureStore();
        await LocalDB.delete(id);
    }
}
